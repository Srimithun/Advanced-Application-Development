package com.example.queensrealm.Entity.token;

public enum TokenType {
    BEARER
}
